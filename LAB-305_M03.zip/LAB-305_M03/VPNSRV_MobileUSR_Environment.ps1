<#	
	Version:        1.0
	Author:         Ahmad Majeed Zahoory
	Creation Date:  16th April, 2022
	Purpose/Change: Build VPN Server and Mobile User Environment

#>

############################################## Variables ############################################################

# Variables for common values
$resourceGroup1 = "az-305-onp-rg"
$resourceGroup2 = "az-305-mobileuser-rg"
$location= "westus"
Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"

# Definer user name and password
$User = "master"
$Password = ConvertTo-SecureString -String "Lab@password" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $Password

############################################## Virtual Network ######################################################
# Create a resource group
New-AzresourceGroup -Name $resourceGroup1 -location $location
New-AzresourceGroup -Name $resourceGroup2 -location $location

# Create a virtual network with subnet for vpn server
$subnet1 = New-AzVirtualNetworkSubnetConfig -Name vpnsubnet -AddressPrefix 192.168.0.0/24
$subnet2 = New-AzVirtualNetworkSubnetConfig -Name usersubnet -AddressPrefix 192.168.1.0/24
$vnet1 = New-AzVirtualNetwork -resourceGroupName $resourceGroup1 -Name onpremises-vnet -AddressPrefix 192.168.0.0/23 `
  -location $location -Subnet $subnet1, $subnet2
  
# Create a virtual network with subnet for mobile user
$subnet1 = New-AzVirtualNetworkSubnetConfig -Name mobileusersubnet -AddressPrefix 172.31.0.0/24
$vnet2 = New-AzVirtualNetwork -resourceGroupName $resourceGroup2 -Name mobileuser-vnet -AddressPrefix 172.31.0.0/24 `
  -location $location -Subnet $subnet1

################################################ VPN Server ##########################################################

# Create a public IP address and specify a DNS name
$pip1 = New-AzPublicIpAddress -resourceGroupName $resourceGroup1 -location $location -Name "vpnsrvdns$(Get-Random)" -AllocationMethod Dynamic -IdleTimeoutInMinutes 4

# Create an inbound network security group rule for port 3389 
$nsgrule1 = New-AzNetworkSecurityRuleConfig -Name vpnsrvrule  -Protocol Tcp `
  -Direction Inbound -Priority 1000 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * `
  -DestinationPortRange "3389" -Access Allow

# Create a network security group
$nsg1 = New-AzNetworkSecurityGroup -resourceGroupName $resourceGroup1 -location $location `
  -Name vpnsrvnsg -SecurityRules $nsgrule1
  
# Create a nic for vm
$nicvm1 = New-AzNetworkInterface -resourceGroupName $resourceGroup1 -location $location -Name 'nicvm1' -SubnetId $vnet1.Subnets[0].Id -PublicIpAddressId $pip1.Id -NetworkSecurityGroupId $nsg1.Id

# Create a virtual machine configuration
$vmConfig1 = New-AzVMConfig -VMName onp-vpnserver -VMSize Standard_D2S_v3 | `
Set-AzVMOperatingSystem -Windows -ComputerName onp-vpnserver -Credential $credential | `
Set-AzVMSourceImage -PublisherName MicrosoftWindowsServer -Offer WindowsServer -Skus 2019-datacenter-gensecond -Version latest | `
Add-AzVMNetworkInterface -Id $nicvm1.Id

# Create a virtual machine
New-AzVM -resourceGroupName $resourceGroup1 -location $location -VM $vmConfig1

########################################## On-Premises Workstation ###################################################

# Create a public IP address and specify a DNS name
$pip2 = New-AzPublicIpAddress -resourceGroupName $resourceGroup2 -location $location -Name "mobileuserdns$(Get-Random)" -AllocationMethod Dynamic -IdleTimeoutInMinutes 4

# Create an inbound network security group rule for port 3389 
$nsgrule2 = New-AzNetworkSecurityRuleConfig -Name mobileuserrule  -Protocol Tcp `
  -Direction Inbound -Priority 1000 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * `
  -DestinationPortRange "3389" -Access Allow

# Create a network security group
$nsg2 = New-AzNetworkSecurityGroup -resourceGroupName $resourceGroup2 -location $location `
  -Name mobileuserrnsg -SecurityRules $nsgrule2
  
# Create a nic for vm
$nicvm2 = New-AzNetworkInterface -resourceGroupName $resourceGroup2 -location $location -Name 'nicvm2' -SubnetId $vnet2.Subnets[0].Id -PublicIpAddressId $pip2.Id -NetworkSecurityGroupId $nsg2.Id

# Create a virtual machine configuration
$vmConfig2 = New-AzVMConfig -VMName mobile-userws -VMSize Standard_D2S_v3 | `
Set-AzVMOperatingSystem -Windows -ComputerName mobile-userws -Credential $credential | `
Set-AzVMSourceImage -PublisherName MicrosoftWindowsDesktop -Offer Windows-10 -Skus win10-21h2-pro-g2 -Version latest | `
Add-AzVMNetworkInterface -Id $nicvm2.Id

# Create a virtual machine
New-AzVM -resourceGroupName $resourceGroup2 -location $location -VM $vmConfig2

  
####End